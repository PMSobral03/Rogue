package pt.iscte.poo.example;

public interface Usable {
	
	public void use();
	
}
